import metier.Applic;

import java.text.ParseException;

public class Main {
    public static void main(String[] args) throws ParseException {
        new Applic();
    }
}