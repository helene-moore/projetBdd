package domaine;

public class Classe {
    private String nom;

    public Classe(String nom) {
        this.nom = nom;
    }
}
