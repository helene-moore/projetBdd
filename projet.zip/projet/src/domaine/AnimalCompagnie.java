package domaine;

public class AnimalCompagnie {
    private String nom;
    private int niveau;
    private int age;
    private String effet;

    public AnimalCompagnie(String nom, int niveau, int age, String effet) {
        this.nom = nom;
        this.niveau = niveau;
        this.age = age;
        this.effet = effet;
    }
}
